0.1. Introduction
A natural disaster is a major adverse event resulting from natural processes of the Earth; examples include firestorms, floods, hurricanes, tornadoes, volcanic eruptions, earthquakes, tsunamis, storms, and other geologic processes. A natural disaster can cause loss of life or damage property,
and typically leaves some economic damage in its wake. The main goal of this website is to grow awareness about natural disasters.

0.2. Purpose: 
This is an  informative website. The main purpose of this website is to share information about these natural events and educate the user how should they prepare for these emergency situations

0.3. Target Audience:
Students needing information for tests or anyone who wants to know about natural disasters. Also, civilians who are seeking information for emergency situations can use this website as well.

0.4. How will target audience use website:
Finding information about different natural disasters and dates for some of the most significant events, as well as how to get ready for these types of natural disasters.

0.5. Scope:
The first iteration will focus on enhancing User Readability and User Engagement.
====================================

UI design:
	Home page
	Volcano page
	Earthquake page
	Tsunami page


Sitemap: Sketch your folder structure:
--------------------------------------
	Main Folder: NaturalDisaster2022

	Sub Folders: 
		Images 		(where all the images will be stored)
		Stylesheets 	(where all my CSS files will be)
	Readme		(Short description of the project)
		
	HTML files for project:
		Index.html
		volcano.html
		earthquake.html
		tsunami.html
All the pages are internally link to each other

index.html is the landing page, which gives the user a overall ideas about the website.

Technilogy Used: HTML, CSS